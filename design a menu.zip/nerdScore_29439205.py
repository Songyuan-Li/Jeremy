# Author: Songyuan Li
# Start date: 2019.4.5
# Last modified date: 2019.4.12
# Student ID: 29439205

def calculateSkillEquation(FandomScore, HobbiesScore, SportsNum):
	skillScore = "Invalid value"
	# judge if any of numbers above are not entered
	if not str(FandomScore).isdigit() or int(FandomScore) <= 0:
		print("Your Fandom Score is not available, please enter a reasonable value.")
	if not str(HobbiesScore).isdigit() or int(HobbiesScore) % 4 != 0:
		print("Your Hobbies Score is not available please enter a reasonable value.")
	if not str(SportsNum).isdigit():
		print("Your Number of Sports Played is not available, please enter a reasonable value.")
	if str(FandomScore).isdigit() and int(FandomScore) > 0 and str(HobbiesScore).isdigit() and \
			int(HobbiesScore) % 4 == 0 and str(SportsNum).isdigit():
		# calculate the skillScore
		skillScore = FandomScore*((42*HobbiesScore**2)/(SportsNum+1))**0.5
	return skillScore
	
	
if __name__ == '__main__':

	FandomScore, HobbiesScore, SportsNum = 1, 4, 1 #the output should be 18.33030277982336
	print(calculateSkillEquation(FandomScore, HobbiesScore, SportsNum))