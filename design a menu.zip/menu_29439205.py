# Author: Songyuan Li
# Start date: 2019.4.5
# Last modified date: 2019.4.12
# Student ID: 29439205
# Description: This program set a menu at first. User should choose options to enter three Scores.If user make any
# mistakes, invalid code will occur which also can give tips to make user enter reasonable value. The option 4 and 5
# can calculate Nerd Score based on input values and print the class.

# Set a menu
Selection = input("Please select a following option.\n1.Enter Fandom Score.\n2.Enter Hobbies Score.\n3.Enter Number of"
                  " Sports Played.\n4.Calculate Nerd Score.\n5.Print Nerd Rating of Students.")
# Set three variables to ensure user input the Score
a = 0
b = 0
c = 0
# Give a condition so that it can run this function many times.
while a <= 1:
    # judge whether input value is digit or not
    if Selection.isdigit():
        if int(Selection) == 1:
            # reset the value
            a = 0
            FandomScore = input("Please enter your Fandom Score ")
            while a == 0:
                # judge whether input value is exist or not
                if FandomScore:
                    # judge whether input value is digit or not
                    if FandomScore.isdigit():
                        if int(FandomScore) <= 0:
                            # report an error and give tips to user
                            FandomScore = input("Fandom Score must be non-zero."
                                                "\nPlease enter a reasonable Fandom Score ")
                        else:
                            # change the value of variables to exit this while function
                            a += 1
                            print("Your Fandom Score is " + FandomScore)
                            # go back to menu , choose another option
                            Selection = input(
                                    'Please select a following option.\n1.Enter Fandom Score.\n2.Enter Hobbies '
                                    'Score.\n3.Enter Number of Sports Played.\n4.Calculate Nerd Score.\n5.Print '
                                    'Nerd Rating of Students.')
                    else:
                        # report an error and give tips to user
                        FandomScore = input("Fandom Score must be a non-zero and non-negative number."
                                            "\nPlease enter a reasonable Fandom Score ")
                else:
                    # must have a FandomScore
                    FandomScore = input("Your Fandom Score is missing, please enter your Fandom Score")
        elif int(Selection) == 2:
            b = 0
            HobbiesScore = input("Please enter your HobblesScore ")
            while b == 0:
                if HobbiesScore:
                    if HobbiesScore.isdigit():
                        if int(HobbiesScore) % 4 == 0:
                            print("Your Hobbies Score is " + HobbiesScore)
                            b += 1
                            Selection = input(
                                'Please select a following option.\n1.Enter Fandom Score.\n2.Enter Hobbies '
                                'Score.\n3.Enter Number of Sports Played.\n4.Calculate Nerd Score.\n5.Print '
                                'Nerd Rating of Students.')
                        else:
                            # report an error and give tips to user
                            HobbiesScore = input('Hobbies Score must be multiples of 4.'
                                                 '\nPlease enter a reasonable Hobbies Score ')
                    else:
                        HobbiesScore = input("Please enter a reasonable Hobbies Score ")
                else:
                    HobbiesScore = input("Your Hobbies Score is missing, please enter your Hobbies Score")
        elif int(Selection) == 3:
            c = 0
            SportsNum = input("Please enter your Number of Sports Played ")
            while c == 0:
                if SportsNum:
                    if SportsNum.isdigit():
                        print("Your Number of Sports Played is " + SportsNum)
                        c += 1
                        # finish inputting value , go back to menu
                        Selection = input("Please select a following option.\n1.Enter Fandom Score.\n2.Enter Hobbies "
                                          "Score.\n3.Enter Number of Sports Played.\n4.Calculate Nerd Score.\n5.Print "
                                          "Nerd Rating of Students.")
                    else:
                        # report an error and give tips to user
                        SportsNum = input("This Score must be a positive number"
                                          "\nPlease enter a reasonable Number of Sports Played ")
                else:
                    SportsNum = input(
                        'Your Number of Sports Played is missing, please enter your Number of Sports Played')
        elif int(Selection) == 4:
            # judge all of scores have been input
            if a == b == c == 1:
                print("\nYour Nerd Score is ")
                break
            # find out which score has not been input
            elif a == 0:
                if b == 0 and c == 0:
                    print("All of Your Score are missing")
                    Selection = input("Please select a following option.\n1.Enter Fandom Score.\n2.Enter Hobbies "
                                      "Score.\n3.Enter Number of Sports Played.\n4.Calculate Nerd Score.\n5.Print "
                                      "Nerd Rating of Students.")
                elif b == 0:
                    print("Your Fandom Score and Hobbies Score are missing")
                    Selection = input("Please select a following option.\n1.Enter Fandom Score.\n2.Enter Hobbies "
                                      "Score.\n3.Enter Number of Sports Played.\n4.Calculate Nerd Score.\n5.Print "
                                      "Nerd Rating of Students.")
                elif c == 0:
                    print("Your Fandom Score and Number of Sports Played are missing")
                    Selection = input("Please select a following option.\n1.Enter Fandom Score.\n2.Enter Hobbies "
                                      "Score.\n3.Enter Number of Sports Played.\n4.Calculate Nerd Score.\n5.Print "
                                      "Nerd Rating of Students.")
                else:
                    print("Your Fandom Score is missing")
                    Selection = input("Please select a following option.\n1.Enter Fandom Score.\n2.Enter Hobbies "
                                      "Score.\n3.Enter Number of Sports Played.\n4.Calculate Nerd Score.\n5.Print "
                                      "Nerd Rating of Students.")
            elif b == 0:
                if c == 0:
                    print("Your Hobbies Score and Number of Sports Played are missing")
                    Selection = input("Please select a following option.\n1.Enter Fandom Score.\n2.Enter Hobbies "
                                      "Score.\n3.Enter Number of Sports Played.\n4.Calculate Nerd Score.\n5.Print "
                                      "Nerd Rating of Students.")
                else:
                    print("Your Hobbies Score is missing")
                    Selection = input("Please select a following option.\n1.Enter Fandom Score.\n2.Enter Hobbies "
                                      "Score.\n3.Enter Number of Sports Played.\n4.Calculate Nerd Score.\n5.Print "
                                      "Nerd Rating of Students.")
            else:
                print("Your Number of Sports Played is missing")
                Selection = input("Please select a following option.\n1.Enter Fandom Score.\n2.Enter Hobbies "
                                  "Score.\n3.Enter Number of Sports Played.\n4.Calculate Nerd Score.\n5.Print "
                                  "Nerd Rating of Students.")
        elif int(Selection) == 5:
            print("Your class is ")
            break
        else:
            # report an error when user's option is invalid
            print("Please choose 1-5 to select a option")
            Selection = input("Please select a following option.\n1.Enter Fandom Score.\n2.Enter Hobbies "
                              "Score.\n3.Enter Number of Sports Played.\n4.Calculate Nerd Score.\n5.Print Nerd Rating "
                              "of Students.")
    else:
        print("Please choose 1-5 to select a option")
        Selection = input("Please select a following option.\n1.Enter Fandom Score.\n2.Enter Hobbies "
                          "Score.\n3.Enter Number of Sports Played.\n4.Calculate Nerd Score.\n5.Print Nerd Rating of "
                          "Students.")
