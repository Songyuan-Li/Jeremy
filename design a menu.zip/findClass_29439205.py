# Author: Songyuan Li
# Start date: 2019.4.5
# Last modified date: 2019.4.12
# Student ID: 29439205


def countStudentClass(studentScore_list):
	if len(studentScore_list) < 1:
		print("Please add at least 1 item into the list")
		return 0
	nerdCount_list = [0] * 7
	for Score in studentScore_list:
		# judge if the items in the list is digit
		if not str(Score).isdigit():
			print("The item in the list must be positive value")
			return "Invalid input"
		if str(Score).isdigit():
			# add related value based on its range
			if Score == 0:
				nerdCount_list[0] += 1
			if 10 > Score >= 1:
				nerdCount_list[1] += 1
			if 100 > Score >= 10:
				nerdCount_list[2] += 1
			if 500 > Score >= 100:
				nerdCount_list[3] += 1
			if 1000 > Score >= 500:
				nerdCount_list[4] += 1
			if 2000 > Score >= 1000:
				nerdCount_list[5] += 1
			if Score >= 2000:
				nerdCount_list[6] += 1
	return nerdCount_list
	
	
if __name__ == '__main__':

	#test cases
	#studentScore_list = []  #
	studentScore_list = [23, 76, 1300, 600]   #output should be [0, 0, 2, 0, 1, 1, 0]


	print(countStudentClass(studentScore_list))
	