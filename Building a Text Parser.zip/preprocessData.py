import re

def preprocessLine(inputLine):
	a = inputLine
	a = a.replace("&amp;", "&")
	a = a.replace("&quot;", "\"")
	a = a.replace("&apos;", "'")
	a = a.replace("&gt;", ">")
	a = a.replace("&lt;", "<")
	a = a.replace("&#xA;", "")
	a = a.replace("&#xD;", "")
	a = re.sub("<(.*?)>", "", a)
	return a

def splitFile(inputFile, outputFile_question, outputFile_answer):
	data_set = open(inputFile, "r", encoding="utf8")
	question = open(outputFile_question, "w", encoding="utf8")
	answer = open(outputFile_answer, "w", encoding="utf8")
	for line in data_set:
		body = re.compile('Body="(.*)" />')
		body_compile = re.findall(body, line)
		body_string = "".join(body_compile)
		body_transform = preprocessLine(body_string)
		Post_typeid = re.compile('PostTypeId="(.*?)"')
		a_list = re.findall(Post_typeid, line)
		a = "".join(a_list)
		if a == "1":
			question.write(body_transform+"\n")
		elif a == "2":
			answer.write(body_transform+"\n")
		

if __name__ == "__main__":

	f_data = "data.xml"
	f_question = "question.txt"
	f_answer = "answer.txt"

	splitFile(f_data, f_question, f_answer)
