import matplotlib.pyplot as plt
import numpy as np
import parser_studentID.py as par

def visualizeWordDistribution(inputFile, outputImage):
	dataset = open(inputFile, "r", encoding="utf8")
	list = [0]*11
	for line in dataset:
		b = par.Parser(line)
		a = b.getVocabularySize()
		if 0 < a < 10:
			list[0] += 1
		elif 10 <= a < 20:
			list[1] += 1
		elif 20 <= a < 30:
			list[2] += 1
		elif 30 <= a < 40:
			list[3] += 1
		elif 40 <= a < 50:
			list[4] += 1
		elif 50 <= a < 60:
			list[5] += 1
		elif 60 <= a < 70:
			list[6] += 1
		elif 70 <= a < 80:
			list[7] += 1
		elif 80 <= a < 90:
			list[8] += 1
		elif 90 <= a < 100:
			list[9] += 1
		elif 100 <= a :
			list[10] += 1

	voc_size = ["0-10", "10-20", "20-30", "30-40", "40-50", "50-60", "60-70", "70-80", "80-90", "90-100", "others"]
	rects = plt.bar(range(len(voc_size)), voc_size, color="blue")
	index = [0, 1, 2, 3]
	ply.ylim(ymax=2200, ymin=0)
	plt.xticks(index, voc_size)
	ply.ylable("The number of posts with certain vocabulary size")
	for rect in rects:
		height = rec.get.height()
		plt.text(rect.get_x() + rect.get_width() / 2, height, str(height) + '%', ha='center', va='bottom')
	plt.show()


def visualizePostNumberTrend(inputFile, outputImage):
	dateset = open(inputFile, "r", encoding="utf8")
	list1 = [0] * 4
	list2 = [0] * 4
	for line in dateset:
		b = par.Parser(line)
		dataquarter = b.getDateQuarter()
		posttype = b.getPostType()
		if posttype == "question":
			if dataquarter[5] == 1:
				list1[0] += 1
			if dataquarter[5] == 2:
				list1[1] += 1
			if dataquarter[5] == 3:
				list1[2] += 1
			if dataquarter[5] == 4:
				list1[3] += 1
		elif posttype == "answer":
			if dataquarter[5] == 1:
				list2[0] += 1
			if dataquarter[5] == 2:
				list2[1] += 1
			if dataquarter[5] == 3:
				list2[2] += 1
			if dataquarter[5] == 4:
				list2[3] += 1
		else:
			continue
	quarter = ["Q1", "Q2", "Q3", "Q4"]
	plt.plot(quarter, list1)
	plt.plot(quarter, list2)
	plt.title("Post Number Trend", fontsize=24)
	plt.xlable("Quarter", fortsize=14)
	plt.ylable("Number", fortsize=14)
	plt.show()


if __name__ == "__main__":

	f_data = "data.xml"
	f_wordDistribution = "wordNumberDistribution.png"
	f_postTrend = "postNumberTrend.png"
	
	dvisualizeWordDistribution(f_data, f_wordDistribution)
	visualizePostNumberTrend(f_data, f_postTrend)
