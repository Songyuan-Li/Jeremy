
class Parser:
	"""docstring for ClassName"""
	def __init__(self, inputString):
		self.inputString = inputString
		self.ID = self.getID()
		self.type = self.getPostType()
		self.dateQuarter = self.getDateQuarter()
		self.cleanBody = self.getCleanedBody()

	def __str__(self):
		#print ID, Question/Answer/Others, creation date, the main content
		return "ID = "+str(self.ID)+"\n"+"PostType = "+str(self.type)+"\n"+"CreationDate = "+str(self.dateQuarter)+"\n"\
			   +"The main content = "+str(self.cleanBody)

	def getID(self):
		ID_compile = re.compile('<row Id=(.*?)')
		self.ID = re.findall(ID_compile,self.inputString)
		return self.ID

	def getPostType(self):
		PostType_compile = re.compile('PostTypeId="(.*?)"')
		PostTypeId = re.findall(PostType_compile, self.inputString)
		a = "".join(PostTypeId)
		if a == "1":
			PostType = "question"
		elif a == "2":
			PostType = "answer"
		else:
			PostType = "others"
		return PostType

	def getDateQuarter(self):
		Year_compile = re.compile('CreationDate="(.*?)-')
		Year = re.findall(Year_compile, self.inputString)
		CreationYear = "".join(Year)
		Month_compile = re.compile('CreationDate=".*?-(.*?)-')
		Month = re.findall(Month_compile, self.inputString)
		CreationMonth = "".join(Month)
		if CreationMonth == "01" or CreationMonth == "02" or CreationMonth == "03":
			DateQuarter = CreationYear + "Q1"
		elif CreationMonth == "04" or CreationMonth == "05" or CreationMonth == "06":
			DateQuarter = CreationYear + "Q2"
		elif CreationMonth == "07" or CreationMonth == "08" or CreationMonth == "09":
			DateQuarter = CreationYear + "Q3"
		elif CreationMonth == "10" or CreationMonth == "11" or CreationMonth == "12":
			DateQuarter = CreationYear + "Q4"
		else:
			DateQuarter = ''
		return DateQuarter

		

	def getCleanedBody(self):
		import preprocessLine
		body = re.compile('Body="(.*)" />')
		body_compile = re.findall(body, self.inputString)
		body_string = "".join(body_compile)
		CleanBody = preprocessLine(body_string)
		return CleanBody
		

	def getVocabularySize(self):
		CleanBody = getCleanedBody(self.inputString)
		CleanBody_lower = CleanBody.lower()
		CleanBody_split = CleanBody_lower.split("")
		CleanBody_set = set(CleanBody_split)
		return(len(CleanBody_set))


		




